
//$("h1").css("color","red");
//$('.banner-text').css("color","#ccc");
//$(document).ready(function(){
  //$(".club-1").mouseover(function(){
    //$(".thumbnail").animate({left: '250px'});
  //});
//});

//$('.btn').on('click',function(){
  //$('story-title').hide();
//});
